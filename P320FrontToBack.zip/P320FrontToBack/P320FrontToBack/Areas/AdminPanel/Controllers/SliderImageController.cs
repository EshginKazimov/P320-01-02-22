﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using P320FrontToBack.DataAccessLayer;
using P320FrontToBack.Models;
using System;
using System.IO;
using System.Threading.Tasks;

namespace P320FrontToBack.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class SliderImageController : Controller
    {
        private readonly AppDbContext _dbContext;
        private readonly IWebHostEnvironment _environment;

        public SliderImageController(AppDbContext dbContext, IWebHostEnvironment environment)
        {
            _dbContext = dbContext;
            _environment = environment;
        }

        public async Task<IActionResult> Index()
        {
            var sliderImages = await _dbContext.SliderImages.ToListAsync();

            return View(sliderImages);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(SliderImage sliderImage)
        {
            if (!ModelState.IsValid)
                return View();

            if (!sliderImage.Photo.ContentType.Contains("image"))
            {
                ModelState.AddModelError("Photo", "Yuklediyiniz shekil olmalidir.");
                return View();
            }

            if (sliderImage.Photo.Length > 1024 * 1000)
            {
                ModelState.AddModelError("Photo", "1 mb-dan az olmalidir.");
                return View();
            }

            var webRootPath = _environment.WebRootPath;
            var fileName = $"{Guid.NewGuid()}-{sliderImage.Photo.FileName}";
            var path = Path.Combine(webRootPath, "img", fileName);

            var fileStream = new FileStream(path, FileMode.CreateNew);
            await sliderImage.Photo.CopyToAsync(fileStream);

            sliderImage.Name = fileName;
            await _dbContext.SliderImages.AddAsync(sliderImage);
            await _dbContext.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}
